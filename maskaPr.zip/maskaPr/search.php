<?php
session_start();


if (!$_SESSION['user']){
  header('Location: index.php');
}


require_once "vendor/connect.php";
require_once "vendor/search.php";


?>
<!DOCTYPE html>
<html>
<head>
    <title>Search</title>
    <link rel='stylesheet' type='text/css' href='style/style.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
</head>
<body>
 
 


<div class='menu'>
  <button type="submit"><a href='main.php'>Головна</a></button>
  <button type="submit"><a href='add.php'>Додати</a></button>
  <button type="submit"><a href='search.php'>Пошук</a></button>
  <div class="export">
            <form action="vendor/read_and_export.php" method="post">
            <button type="submit" id="export" name="export" value="Export to excel" class="btn btn-success">Экспорт в Excel</button>
            </form>
  </div>
  <button type="submit"><a href="vendor/exit.php" style='color: red;'>Вихід</a>
  </div>


     <div class='search'>
    <form method = 'post'>
       
        <h1>Пошук клієнта</h1>
        <input type="text" name="search" class='search_field'> 
        <input type="submit" value="Пошук" name = "searchB" class='seacrh_button'>
     </form>
    </div>



    <div class='table'>
<table>
    <tr>
      <th>id</th>
      <th>Ім'я</th>
      <th>Прізвище</th>
      <th>По батькові</th>
      <th>Дата народження</th>
      <th>Номер телефону</th>
      <th>E-mail</th>
      <th>&#9998;</th>
      <th>&#10006;</th>
    </tr>

    <?php
    foreach($row as $resulte) {
        ?>
          <tr>
            <td><?= $resulte[0] ?></td>
            <td><?= $resulte[1] ?></td>
            <td><?= $resulte[2] ?></td>
            <td><?= $resulte[3] ?></td> 
            <td><?= $resulte[4] ?></td> 
            <td><?= $resulte[5] ?></td>
            <td><?= $resulte[6] ?></td> 
            <td><a href="update.php?id=<?= $resulte[0] ?>">Оновити</a></td>
            <td><a href="vendor/delete.php?id=<?= $resulte[0] ?>">Видалити</a></td>
          </tr>
        <?php
      }
       ?>
  </table>
    </div>

 </body>
 </html>