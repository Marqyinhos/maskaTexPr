<?php
session_start();


if (!$_SESSION['user']){
  header('Location: index.php');
}
  require_once 'vendor/connect.php';
  
  $customer_id = $_GET['id'];
  $customer = mysqli_query($connect, "SELECT * FROM `customers` WHERE `id`='$customer_id'");
  $customer = mysqli_fetch_assoc($customer);
  
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel='stylesheet' type='text/css' href='style/style.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
  <title>Update</title>
</head>
<body>

  
 

  <h2>Оновити</h2>
  <div class = 'update'>
  <form action="vendor/update.php" method="post">
    <input type="hidden" name="id" value="<?= $customer['id'] ?>">
    <p>Ім'я</p>
    <input type="text" name="first_name" value="<?= $customer['first_name'] ?>">
    <p>Прізвище</p>
    <input type="text" name="second_name" value="<?= $customer['second_name'] ?>">
    <p>По батькові</p>
    <input type="text" name="patronymic" value="<?= $customer['patronymic'] ?>">
    <p>Дата народження</p>
    <input type="date" name="birthdate" value="<?= $customer['birthdate'] ?>">
    <p>Номер телефону</p>
    <input type="number" name="telephone" value="<?= $customer['telephone'] ?>">
    <p>E-mail</p>
    <input type="text" name="email" value="<?= $customer['email'] ?>">
  
    <button type="submit">Оновити</button>
  </form>
  
    </div>





  


</body>
</html>