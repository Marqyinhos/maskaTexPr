<?php
session_start();


if (!$_SESSION['user']){
  header('Location: index.php');
}


require_once "vendor/connect.php";

$customers = mysqli_query ($connect, "SELECT * FROM `customers`");
$customers = mysqli_fetch_all ($customers);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add</title>
    <link rel='stylesheet' type='text/css' href='style/style.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
</head>
<body>
    
  


<div class='menu'>
  <button type="submit"><a href='main.php'>Головна</a></button>
  <button type="submit"><a href='add.php'>Додати</a></button>
  <button type="submit"><a href='search.php'>Пошук</a></button>
  <div class="export">
            <form action="vendor/read_and_export.php" method="post">
            <button type="submit" id="export" name="export" value="Export to excel" class="btn btn-success">Экспорт в Excel</button>
            </form>
  </div>
  <button type="submit"><a href="vendor/exit.php" style='color: red;'>Вихід</a></button>
  </div>


    <div class='main'>
        <div class='add'>
        <h1>Додати клієнта</h1>
        <form action='vendor/create.php' method='post'>
          
          <input type='text' name='first_name' placeholder="Ім'я">
          
          <input type='text' name='second_name' placeholder='Прізвище'>
          
          <input type='text' name='patronymic' placeholder='По батькові'>

          <input type='date' name='birthdate' placeholder='Дата народження'>

          <input type='number' name='telephone' placeholder='Номер телефону'>

          <input type='text' name='email' placeholder='E-mail'>


          <button type='submit'>Додати</button>
        </form>

                </div>
    

                </div>
</body>
</html>