<?php
session_start();


if (!$_SESSION['user']){
  header('Location: index.php');
}


require_once "vendor/connect.php";

$customers = mysqli_query ($connect, "SELECT * FROM `customers`");
$customers = mysqli_fetch_all ($customers);


?>
<!DOCTYPE html>
<html>
<head>
    <title>Main</title>
    <link rel='stylesheet' type='text/css' href='style/style.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@500&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="image/db.png">
</head>
<body>
 
 

  
  <div class='menu'>
  <button type="submit"><a href='main.php'>Головна</a></button>
  <button type="submit"><a href='add.php'>Додати</a></button>
  <button type="submit"><a href='search.php'>Пошук</a></button>
  <div class="export">
            <form action="vendor/read_and_export.php" method="post">
            <button type="submit" id="export" name="export" value="Export to excel" class="btn btn-success">Экспорт в Excel</button>
            </form>
  </div>
  <button type="submit"><a href="vendor/exit.php" style='color: red;'>Вихід</a></button>
  </div>



<div class='table'>
  
<table class="table_sort">
  <thead>
    <tr>
      <th>id</th>
      <th>Ім'я</th>
      <th>Прізвище</th>
      <th>По батькові</th>
      <th>Дата народження</th>
      <th>Номер телефону</th>
      <th>E-mail</th>
      <th>&#9998;</th>
      <th>&#10006;</th>
    </tr>
</thead>
<tbody>
    <?php
    foreach($customers as $customer) {
        ?>
          <tr>
            <td><?= $customer[0] ?></td>
            <td><?= $customer[1] ?></td>
            <td><?= $customer[2] ?></td>
            <td><?= $customer[3] ?></td> 
            <td><?= $customer[4] ?></td> 
            <td><?= $customer[5] ?></td> 
            <td><?= $customer[6] ?></td> 
            <td><a href="update.php?id=<?= $customer[0] ?>">Оновити</a></td>
            <td><a href="vendor/delete.php?id=<?= $customer[0] ?>">Видалити</a></td>
          </tr>
        <?php
      }
       ?>
       </tbody>
  </table>
    </div>
  
    <script>
document.addEventListener('DOMContentLoaded', () => {

const getSort = ({ target }) => {
    const order = (target.dataset.order = -(target.dataset.order || -1));
    const index = [...target.parentNode.cells].indexOf(target);
    const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
    const comparator = (index, order) => (a, b) => order * collator.compare(
        a.children[index].innerHTML,
        b.children[index].innerHTML
    );

    for(const tBody of target.closest('table').tBodies)
        tBody.append(...[...tBody.rows].sort(comparator(index, order)));

    for(const cell of target.parentNode.cells)
        cell.classList.toggle('sorted', cell === target);
};

document.querySelectorAll('.table_sort thead').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));

});
</script>

        

 
    
</body>
</html>